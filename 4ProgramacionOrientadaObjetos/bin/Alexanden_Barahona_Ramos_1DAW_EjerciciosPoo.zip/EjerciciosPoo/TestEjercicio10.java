package EjerciciosPoo;

public class TestEjercicio10 {
	//CONSUMO
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ejercicio10 c1 = new Ejercicio10(500, 30, 120, 1.2);
		System.out.println(c1);
		
		System.out.println(c1.getTiempo());
		System.out.println(c1.consumoMedio());
		System.out.println(c1.consumoEuros());
		
	}

}
