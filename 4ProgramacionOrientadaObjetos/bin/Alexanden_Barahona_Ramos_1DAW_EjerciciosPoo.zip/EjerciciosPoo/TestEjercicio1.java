package EjerciciosPoo;

public class TestEjercicio1 {
	//TEMPERATURA
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Ejercicio1.celciusToFarenheit(22)+" Farenhheit");
		System.out.println(Ejercicio1.farenheitToCelsius(150)+ " Celcius");
	}

}
