package EjerciciosPoo;
	//CONVERSOR  DE MILLAS 
public class Ejercicio4 {

	/**
	 * metodo conversot de milla a metros
	 * @param millas
	 * @return
	 */
	public static double millasMetros(double millas) {
		return millas*(1609.34/1);
	}
	/**
	 * metodo conversor de millas a kilometros
	 * @param millas
	 * @return
	 */
	public static double millisKilometros(double millas) {
		return (millas*1.60934)/1;
	}
	
}
