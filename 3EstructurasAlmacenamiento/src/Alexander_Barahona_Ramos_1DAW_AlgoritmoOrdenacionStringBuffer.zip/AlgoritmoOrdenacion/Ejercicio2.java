package AlgoritmoOrdenacion;

public class Ejercicio2 {
/*
 *Mejora el m�todo de la burbuja explicado anteriormente y utiliza una 
 *variable a modo de centinela o flag, de tal manera que �sta se active 
 *cuando hay alg�n intercambio. En el momento que no haya ning�n 
 *intercambio, el algoritmo deber�a parar puesto que el vector ya est� 
 *ordenado.
 */

	/**
	 * metodo burbuja mejorado ordena un array
	 * @param vector
	 * @return
	 */
	public static int[] burbujaMejorado (int vector[]) {
        int aux=0;
        boolean flag=false;

            for (int i = 0; flag!=true; i++) {
                flag=true;
                for (int j = 0; j < vector.length - i - 1; j++) {
                    if (vector[j + 1] < vector[j]) {
                        aux = vector[j + 1];
                        vector[j + 1] = vector[j];
                        vector[j] = aux;
                        flag=false;
                    }
                }
            }
        return vector;
    }
	/**
	 * metodo rrellena un vecotr con numeros ramdom
	 * @param vector
	 * @return
	 */
	public static int[]  rellenarVector(int vector[]) {
		for (int i = 0; i < vector.length; i++) {
			vector[i]=(int)(Math.random()*100+1);
		}
		return vector;
	}
	/**
	 * metodo pinta un vector
	 * @param vector
	 */
	public static void pintarVector(int vector[]) {
		for (int i = 0; i < vector.length; i++) {
			System.out.print(vector[i]+" ");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int vector[]=new int[50];
		rellenarVector(vector);
		pintarVector(vector);
		System.out.println();
		burbujaMejorado(vector);
		pintarVector(vector);
	}

}