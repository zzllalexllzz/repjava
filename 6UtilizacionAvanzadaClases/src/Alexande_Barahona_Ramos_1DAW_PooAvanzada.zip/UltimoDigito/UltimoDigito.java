package UltimoDigito;

public class UltimoDigito {

	public Integer UltimoDig(Integer num) {
		Integer ulti= num%10;
		return ulti;
	}
}
