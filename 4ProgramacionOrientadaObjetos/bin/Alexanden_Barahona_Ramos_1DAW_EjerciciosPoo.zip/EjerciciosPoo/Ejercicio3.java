package EjerciciosPoo;
	//PAJARO
public class Ejercicio3 {

	public void setEdad(int e) { edad=e; }
	public void printEdad() { System.out.println(edad); }
	public void setColor(char c) { color=c; }
	private int edad;
	private char color;
	

}
