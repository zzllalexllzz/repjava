package ConversorFechas;

public class TestConversorFecha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConversorFechas cf = new ConversorFechas();
		
		System.out.println(cf.normalToAmericano("04-09-2015"));
		
		System.out.println(cf.americanoToNormal("2002-02-01"));
		
		

	}

}
