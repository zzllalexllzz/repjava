/**
 * 
 */
package EstructuraBasicaControl;

/**
 * @author darge
 *
 */
public class Ejercicio7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int suma=0;
		
		for(int num1=1; num1<=100; num1++) {
			suma=suma+num1;
		}
		System.out.println("la suma de los 100 numeros es "+suma);
	}

}
