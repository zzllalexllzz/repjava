/**
 * 
 */
package String;

import java.util.Scanner;

/**
 * @author darge
 *
 */
public class Ejercicio4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tcl = new Scanner(System.in);
		String cadena1;
		String cadena2;
		
		
		//leemos la cadena 
		System.out.println("introduzca una cadena ");
		cadena1=tcl.nextLine();
		//cadena a buscar
		System.out.println("introducir la cadema a buscar ");
		cadena2=tcl.nextLine();
	}

}
