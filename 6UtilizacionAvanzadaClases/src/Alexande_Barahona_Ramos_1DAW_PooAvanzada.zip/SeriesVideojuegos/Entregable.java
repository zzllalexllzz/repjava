package SeriesVideojuegos;

public interface Entregable {

	public boolean entregar();
	public boolean devolver();
	public boolean isPestado();
}
