package EjerciciosPoo;

public class TestEjercicio11 {
	//ROBOT
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ejercicio11 r1 = new Ejercicio11(99,10);
		
	
		r1.irDerecha();
		System.out.println(r1);
		r1.irDerecha();
		System.out.println(r1);
		r1.irIzquierda();
		System.out.println(r1);
		r1.irArriba();
		System.out.println(r1);
		
		
		
	}

}
