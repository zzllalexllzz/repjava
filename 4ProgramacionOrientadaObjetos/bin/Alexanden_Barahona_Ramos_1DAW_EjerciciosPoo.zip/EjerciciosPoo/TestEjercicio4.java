package EjerciciosPoo;

public class TestEjercicio4 {
	//CONVERSOR DE MILLAS
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Ejercicio4.millasMetros(50)+" Metros");
		System.out.println(Ejercicio4.millisKilometros(50)+" Kilometros");
	}

}
