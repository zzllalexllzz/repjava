/**
 * 
 */
package EstructuraBasicaControl;

/**
 * @author darge
 *
 */
public class Ejercicio4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
