package EjerciciosPoo;

public class TestEjercicio2 {
	//COCHE
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ejercicio2 c1 = new Ejercicio2();
		
		c1.acelera(100);
		System.out.println(c1);
		c1.frenar(20);
		System.out.println(c1);
	}

}
