package Scotify;

public interface Reproducible {

	public void reproducir();
}
