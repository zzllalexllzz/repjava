package EjerciciosPoo;

public class TestEjercicio3 {
	//PAJARO
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ejercicio3 p1 = new Ejercicio3();
		
		p1.setEdad(14);
		p1.setColor('g');
		p1.printEdad();
		/**
		 * Si compila no es necesario que este ordenado la clase ,tambien 
		 * podriamos a�adir un metodo con un swich para distintos colores 
		 * para el setColor.
		 */
	}

}
