/**
 * 
 */
package Arrays;

/**
 * @author darge
 *
 */
public class Ejercicio4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		
		
		for(int i=0; i<num.length; i++) {
			
		}
		for(int i=0; i<=4; i++) {
			System.out.print(num[i]);
			System.out.print(num[9-i]);
		}
	}

}
