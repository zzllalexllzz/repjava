package Triangulo;

public interface Comparable {

	public  int compareTo(Triangulo t);
}
