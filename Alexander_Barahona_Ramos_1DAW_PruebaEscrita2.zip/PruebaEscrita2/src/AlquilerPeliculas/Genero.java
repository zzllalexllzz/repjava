package AlquilerPeliculas;

/**
 * metodo emun  tipo o genero  de pelicula
 * @author darge
 *
 */
public enum Genero {

	THRILLER, ACCION, AVENTURAS, ROM�NTICA, TERROR, INFANTIL, SCIFI, DRAMA, COMEDIA, ORIENTAL
}
