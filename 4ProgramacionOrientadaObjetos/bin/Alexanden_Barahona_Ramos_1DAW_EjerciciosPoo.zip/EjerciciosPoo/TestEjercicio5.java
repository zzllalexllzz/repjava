package EjerciciosPoo;

public class TestEjercicio5 {
	//FINANZAS
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ejercicio5 f1 = new Ejercicio5();
		
		System.out.println(f1);
		System.out.println(f1.dolaresToEuro(25));
		System.out.println(f1.euroToDolar(25));
	}

}
