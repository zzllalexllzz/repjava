package Parking;

public interface Descontable {

	public abstract double descuento();
}
